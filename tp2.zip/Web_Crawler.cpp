#include "Web_Crawler.h"
#include "ClosedQueueException.h"
#include <unistd.h>
#include <utility>
#include <cstddef>
#include <new>
#include <vector>
#include <iostream>

Web_Crawler:: Web_Crawler(const char* argv[]): allowed(),
                                               number_of_threads(),
                                               pages(),
                                               seconds_to_sleep(),
                                               fr(argv[4],argv[1]),
                                               target_list(){
    this->allowed = argv[2];
    this->number_of_threads = std::stoi(argv[3]);
    this->pages = argv[5];
    this->seconds_to_sleep = std::stoi(argv[6]);
    build_map_and_list();
    this->threads.reserve(this->number_of_threads);
}

void Web_Crawler:: build_map_and_list(){
    this->fr.read_file_and_build_map
        (this->index_map);

    this->fr.read_file_and_build_list
        (this->target_list);
}

void Web_Crawler:: spawn_threads(){
    for ( int i = 0; i < this->number_of_threads; i++ ) {
        this->threads.push_back(std::thread([&]{ run(); }));
    }

    sleep(this->seconds_to_sleep);
    close_queue();

    for ( auto& th: threads ){
        th.join();
    }
}

void Web_Crawler:: search_new_urls(const int& offset,const int& size){
    std::vector<char> buffer(size+1);
    
    std::ifstream myfilepages;
    myfilepages.open(this->pages);

    myfilepages.seekg(offset);
    myfilepages.read(buffer.data(),size);

    std::string str(buffer.data());
           
    std::istringstream iss(str);
    std::string word = "";
    while (iss >> word) {
        if ( (word.find(this->allowed) != std::string::npos) &
            (word.find("http://") != std::string::npos) ){
                this->queue.push(word);
            }
    }
    myfilepages.close();
}

void Web_Crawler:: put_initial_values_in_queue(){
    for (std::list<std::string>::iterator it = this->target_list.begin();
             it != this->target_list.end(); ++it){
        this->queue.push(*it);
    }
    this->target_list.clear();
}

void Web_Crawler:: print(){
    this->final_map.print_all_values();
}

void Web_Crawler:: url_was_processed(const std::string& url){
    this->final_map.putIfAbsent(url,0,0);
    this->final_map.setStateIfPresent(url,"explored");
}

void Web_Crawler:: url_was_not_processed(const std::string& url){
    this->final_map.putIfAbsent(url,0,0);
    this->final_map.setStateIfPresent(url,"dead");
}

void Web_Crawler:: run(){
    bool keep_working = true;

    while (keep_working) {
        try{
            std::string next_url = "";
            next_url = this->queue.pop();
            if ( this->index_map.contains_key(next_url) ) {
                int offset = 
                    this->index_map.getOffsetIfPresent(next_url);
                int size   = 
                    this->index_map.getSizeIfPresent(next_url);

                search_new_urls(offset,size);
                
                url_was_processed(next_url);
            }else{
                url_was_not_processed(next_url);
            }
        } catch (ClosedQueueException &error){
            keep_working = false;
        }
    }
}

void Web_Crawler:: close_queue(){
    this->queue.close();
}

void Web_Crawler:: start(){
    put_initial_values_in_queue();
    spawn_threads();
    print();
}

Web_Crawler:: ~Web_Crawler(){}
